<?php

namespace App\Controllers;

class Check extends BaseController
{
    public function index()
    {
        $check=false;
        $fileName = $this->request->getPost("file");
        var_dump(file_get_contents('phar://./uploads/bfe570a81f95e89468517d3475a1704d.png'));
        die();
        $result=getimagesize($fileName);
        if($result){
            echo "The check passes, the picture is normal";
        }else{
            die("This image may be harmful");
        }
    }
}

