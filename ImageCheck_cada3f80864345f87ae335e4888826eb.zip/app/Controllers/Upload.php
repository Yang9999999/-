<?php

namespace App\Controllers;

class Upload extends BaseController
{
    public function index()
    {
        if ($file = $this->request->getFile("file")) {
            if (preg_match('/HALT_COMPILER|php|<\?/im', file_get_contents($file->getTempName()))) {
                die("<center>Hacker!!!!!<br/><img src='/hacker.png'></center>");
            }
            if(in_array($file->getExtension(),array('jpg','png','gif'))){
                $md5name = md5($file->getFilename()) . '.' . $file->getExtension();
                $file->move( 'uploads', $md5name);
                die("<script>window.location.href='/index.php/Check?file=uploads/$md5name'</script>");
            }else{
                die("Hacker");
            }
        }
    }
}

