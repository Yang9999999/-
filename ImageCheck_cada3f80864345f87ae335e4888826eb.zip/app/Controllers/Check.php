<?php

namespace App\Controllers;

class Check extends BaseController
{
    public function index()
    {
        $check=false;
        $fileName = $this->request->getGet("file");
        $result=getimagesize($fileName);
        if($result){
            echo "The check passes, the picture is normal";
        }else{
            die("This image may be harmful");
        }
    }
}

