<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
    <meta name="description" content="The small framework with powerful features">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="/favicon.ico"/>
</head>
<body>
<center>
    <h2>让我康康你的图片</h2>
<form action="/index.php/upload"
      method="POST" enctype="multipart/form-data">
    <input type="file" name="file"/>
    <input type="submit">
</form>
</center>
</body>
</html>

